// CoopOS Demo  (C) 2019 Helmut Weber  [ www.HelmutWeber.de ] Kurs-5


#ifndef COOPOS_H
#define COOPOS_H

#include <Arduino.h>


// Config
//---------------------------------------------------------------------------------
#define MAXTASKS 10
#define INTERNAL_PRIO
#define LA
#define NO_WLAN         // Schneller ohne WLAN
//---------------------------------------------------------------------------------

struct tcb {
    char        *Name;          // Name des Tasks als Text
    void        (*Func)();      // Name des Tasks
    uint8_t     Priority;       // Priorität // reserved
    uint32_t    LastCalled;     // Zeit: letzter Aufruf
    uint32_t    Delay;          // Verzögerung für Task
    char        State;          // Status: READY, DELAYED
};

enum state { READY, DELAYED, BLOCKED };


// Defines for TaskSwitching
//---------------------------------------------------------------------------------
#define taskBegin()                                                            \
  static int _mark = 0;                                                        \
  switch (_mark) {                                                             \
  case 0:

#define taskEnd()    _mark=0;\
    return;  \
  }


#define taskSwitch() _mark=__LINE__; return;  case __LINE__:

extern struct tcb *thisTask;

#define taskDelay(val)    _mark=__LINE__; thisTask->Delay =val; thisTask->State=DELAYED; return; case __LINE__:

#define taskStop(id)      _mark=__LINE__; Tasks[id]Delay =0;    Task[id].State=BLOCKED;

#define taskStopMe()      _mark=__LINE__; thisTask->Delay =0;   thisTask->State=BLOCKED; return; case __LINE__:

#define taskResume(id)    _mark=__LINE__; Tasks[id].Delay =0;   Tasks[id].State=READY; return; case __LINE__:



//---------------------------------------------------------------------------------



// Globals
//---------------------------------------------------------------------------------
int             numTasks;
struct tcb      Tasks[MAXTASKS];
struct tcb      *thisTask;
//---------------------------------------------------------------------------------


// -------------------------------------------------
uint32_t SchedulerCalls;

void Scheduler() {
    uint32_t     m;

    for (int i=0; i<numTasks; i++) {
        SchedulerCalls++;
#ifdef LA
        digitalWrite(15,HIGH);
        digitalWrite(15,LOW);
#endif
        m=micros();
        thisTask = &Tasks[i];
        if (thisTask->State == DELAYED) {
            if ((m-thisTask->LastCalled) >= thisTask->Delay) {
                thisTask->State = READY;
            } else  {
                thisTask->State=DELAYED;
            }
        }


        if (thisTask->State == READY) {
            thisTask->Func();                  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< call the Task
            //Serial.println(thisTask->Delay);
            thisTask->LastCalled = m;
#ifdef INTERNALPRIO
            break;
#endif
        }
    } // for
} // Scheduler
// -------------------------------------------------

int TaskInit(char *name, void (*f)(void), uint8_t priority, state stat, uint32_t del) {
    if (numTasks >= MAXTASKS) {
        Serial.println("ERR: MAXTASKS");
        return -1;                                // Fehler
    }

    Tasks[numTasks].Name =        name;
    Tasks[numTasks].Func =        f;
    Tasks[numTasks].Priority =    priority;     // reserved
    Tasks[numTasks].State =       stat;
    Tasks[numTasks].Delay =       del;
    if (Tasks[numTasks].Delay) Tasks[numTasks].State =  DELAYED;

    numTasks++;
    return (numTasks-1);
}

// -------------------------------------------------


#endif
