// CoopOS Demo  (C) 2019 Helmut Weber  [ www.HelmutWeber.de ] Lesson-8




#ifndef COOPOS_H
#define COOPOS_H

#include <Arduino.h>
#include "pins.h"

// Config
//---------------------------------------------------------------------------------
#define MAXTASKS 10
#define MAXRESOURCE 3
#define INTERNAL_PRIO
#define LA
//#define NO_WLAN              / faster without WLAN
//---------------------------------------------------------------------------------
volatile uint8_t         Resource[MAXRESOURCE];

enum state { READY, DELAYED, BLOCKED, WAITSIG, WAITRES };



int             numTasks=1;     // Task0 is reserved for Idle (to do)
uint8_t         HiPrio=0;



class tcb {
public:
    uint8_t     ID;             // InitTask() returns thisTask-Handle
    char        *Name;          // Name of Tassk as Text
    void        (*Func)();      // Name of Task-Functin
    uint8_t     Priority;       // Priority // reserved
    uint32_t    LastCalled;     // Time: last called
    uint32_t    Delay;          // Delay of Task
    state       State;          // State: READY, DELAYED
    uint8_t     Signal;         // wait for a signal
    uint8_t     Resource;       // wait for a resource
};



// Defines for TaskSwitching
//---------------------------------------------------------------------------------
#define taskBegin()                                                            \
  static int _mark = 0;                                                        \
  switch (_mark) {                                                             \
  case 0:

#define taskEnd()    _mark=0;\
    return;  \
  }


#define taskSwitch() _mark=__LINE__; return;  case __LINE__:

extern struct tcb *thisTask;

#define taskDelay(val)    _mark=__LINE__; thisTask->Delay =val; thisTask->State=DELAYED; return; case __LINE__:

// kann auf vom ISR benutzt werden:
#define taskStop(id)      _mark=__LINE__; Tasks[id]Delay =0;    Task[id].State=BLOCKED;

#define taskStopMe()      _mark=__LINE__; thisTask->Delay =0;   thisTask->State=BLOCKED; return; case __LINE__:

#define taskResume(id)    _mark=__LINE__; Tasks[id].Delay =0;   Tasks[id].State=READY; return; case __LINE__:

#define taskWaitSig(sig)  _mark=__LINE__; thisTask->Delay =0;   thisTask->Signal=sig; thisTask->State=WAITSIG; return; case __LINE__:

// kann auch vom ISR benutzt werden:
#define taskSetSig(sig)  \
for (int ix=1; ix<numTasks; ix++) {\
struct tcb *tp;\
  tp=&Tasks[ix];\
  if (tp->Signal==sig) {\
    tp->Signal=0; tp->State=READY;\
    if (!HiPrio)  HiPrio=ix; \
  }\
}


#define taskWaitRes(res)  _mark=__LINE__; \
/*Serial.print("Wait RES "); Serial.print(res); Serial.print(".. Task " ); Serial.println(thisTask->ID);*/\
/*  Wenn die resource frei ist, dann sofort weiter */\
if (Resource[res]==0) {\
  Resource[res]=thisTask->ID;\
  /*Serial.print("RES is free, Resource "); Serial.println(res);*/\
}\
/*  Wenn die resource NICHTfrei ist: gehört sie mir schon ? */\
else {\
  if (Resource[res]==thisTask->ID) {\
    /*Serial.print("RES is mine, Task "); Serial.println(thisTask->ID);*/\
  }\
  /*  ist fremd besetzt ! Task muss warten */\
  else {\
    /*Serial.print("RES wait, Task "); Serial.println(thisTask->ID);*/\
    thisTask->Resource=res;\
    thisTask->State=WAITRES; \
    taskSwitch();\
  }\
}


// could only be used from owner of resource (not ISR)

#define taskFreeRes(res)  \
/*Serial.print(thisTask->ID); Serial.print("  frees ... "); Serial.println(Resource[res]); */\
if (Resource[res] == thisTask->ID) {\
  /*Serial.println("FREE - RES is mine");*/\
  Resource[res] = 0;\
  for (int ix=1; ix<numTasks; ix++) {\
  struct tcb *tp;\
    tp=&Tasks[ix];\
    if (tp->State == WAITRES) {\
      if (tp->Resource==res) {\
        /*Serial.print(thisTask->ID); Serial.print(" enables "); Serial.println(tp->ID);*/\
        tp->Resource=0; tp->State=READY;\
        Resource[res]=tp->ID;\
        break;\
      }\
    }\
  }\
}


//---------------------------------------------------------------------------------



// Globals
//---------------------------------------------------------------------------------

tcb      Tasks[MAXTASKS];
tcb      *thisTask;

//---------------------------------------------------------------------------------


class Sched {
public:

    Sched() { };


// -------------------------------------------------

    void Scheduler() {
        uint32_t        m;
        extern uint32_t SchedCount;
        uint8_t i_start=1;

Start:

        if (HiPrio) i_start=HiPrio ;
        HiPrio=0;

        for (int i=i_start; i<numTasks; i++) {
#ifdef LA
            digitalWrite(LA_PIN,HIGH);
            digitalWrite(LA_PIN,LOW);
#endif
            if (HiPrio) goto Start;

            SchedCount++;
            m=micros();
            thisTask = &Tasks[i];
            if (thisTask->State == DELAYED) {
                if ((m-thisTask->LastCalled) >= thisTask->Delay) {
                    thisTask->State = READY;
                }
                //else  { thisTask->State=DELAYED; }
            }
            if (HiPrio) goto Start;

            if (thisTask->State == READY) {
                thisTask->Func();                  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< call the Task
                //Serial.println(thisTask->Delay);
                thisTask->LastCalled = m;
                if (HiPrio) goto Start;
#ifdef INTERNAL_PRIO
                return;
#endif
            }
        } // for
    } // Scheduler
// -------------------------------------------------

    int TaskInit(char *name, void (*f)(void), uint8_t priority, state stat, uint32_t del) {
        if (numTasks >= MAXTASKS) {
            Serial.println("ERR: MAXTASKS");
            return -1;                                // Error
        }

        Tasks[numTasks].ID =          numTasks;
        Tasks[numTasks].Name =        name;
        Tasks[numTasks].Func =        f;
        Tasks[numTasks].Priority =    priority;     // reserved
        Tasks[numTasks].State =       stat;
        Tasks[numTasks].Delay =       del;
        if (Tasks[numTasks].Delay) Tasks[numTasks].State =  DELAYED;

        numTasks++;
        return (numTasks-1);
    }

// -------------------------------------------------


#endif

};
